-- You can run shell commands from within the mysql console and HENCE, from mysql scripts.
-- The space between the \! and the command is important.
\! ls -l
