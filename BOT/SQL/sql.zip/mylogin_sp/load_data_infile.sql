SET @CUST := 100001 ;
SET @FILE := '/home01/derrick/LISTS/homebiz_coreg-6-19-08-6.txt';
SET @DESCRIPTION := 'Kombol List' ;
SET @KEYWORDS := '' ;




INSERT INTO masterimportarchive (custid,filename,importdate,keywords,description) VALUES (100001,@FILE,NOW(),@KEYWORDS,@DESCRIPTION) ;


LOAD DATA LOCAL INFILE @FILE IGNORE INTO TABLE `tblmastertmp` 
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\n' 
-- IGNORE 1 LINES 
(
firstname, 
lastname, 
address, 
city, 
region,
zipcode, 
companyname, 
email, 
phonenum, 
fax, 
dtTimeStamp, 
ip, 
source
) 
SET
dateadded = CURRENT_DATE,
custid = @CUST ;

LOAD DATA LOCAL INFILE '/tmp/6739_unsubscribe.txt' IGNORE INTO TABLE d6940.unsubscribe FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\n' (email, tsAdded) ;

mysql -e "load data infile '/home/derrick/Desktop/domains.txt' ignore into table system.tblglobal_domains fields terminated by ',' optionally enclosed by '"' lines terminated by '\n' (domain_name)" -u admin -p -h master
