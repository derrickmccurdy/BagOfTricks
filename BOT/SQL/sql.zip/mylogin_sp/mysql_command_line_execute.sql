mysql -e "show full processlist" -u admin --password=aslkjfsdddddd -h 216.66.17.204 
